export class Student {
  position: string;
  username: string;
  class: string;
  year: string;
  school: string;
  isEdit: boolean;
}
export class User {
  id: number;
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  authdata?: string;
}
